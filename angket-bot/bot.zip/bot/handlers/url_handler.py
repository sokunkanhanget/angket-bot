"""
bot/handlers/url_handler.py
===========================
Telegram wiring for URL checking. Thin on purpose — the real logic
lives in bot/analysis/url_analyzer.py.

Pattern: send a "Checking..." message first, then EDIT it into the
result (like file_handler.py does with its "Scanning..." message).
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

import secrets

from bot.analysis.url_analyzer import check_message, format_verdict
from bot.analysis.utils import log_url_scan


async def handle_url(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Guard: skip updates that aren't real text messages.
    print(f"[handle_url] msg={update.message} | callback={update.callback_query} | edited={update.edited_message}")
    if update.message is None or update.message.text is None:
        return
    print(f"[handle_url] passed guard, text={update.message.text!r}")

    text = update.message.text
    user_id = update.effective_user.id

    verdicts = check_message(text)

    # No links → this handler only speaks about URLs.
    if not verdicts:
        await update.message.reply_text("🔗 No links found in that message.")
        return

    # Step 1: send a placeholder we can edit into the result.
    status = await update.message.reply_text("🔍 *Checking link...*", parse_mode="Markdown")
    
    # Log every checked URL to the database.
    for verdict in verdicts:
        log_url_scan(user_id, verdict["host"], verdict["score"], verdict["level"])

    full = "\n\n---\n\n".join(format_verdict(v) for v in verdicts)

    risky = [v for v in verdicts if v["level"] != "safe"]
    if risky:
        summary = "Link looks sus"
    else:
        summary = "Link is okay. Be aware"

    ticket = secrets.token_hex(4)
    context.user_data[ticket] = full
    label = "Why?" if risky else "See details"
    keyboard = InlineKeyboardMarkup(
        [[InlineKeyboardButton(label, callback_data=f"why:{ticket}")]]
    )
    # Step 2: edit the placeholder into the final verdict.
    await status.edit_text(
        summary,
        parse_mode="Markdown",
        disable_web_page_preview=True,  # don't preview a possibly-bad link
        reply_markup=keyboard,
    )

async def see_why_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show the stashed breakdown when user taps Why?"""
    query = update.callback_query

    ticket = query.data.split(":", 1)[1]
    full = context.user_data.pop(ticket, None)

    if full is None:
        await query.answer("The result expired")
        return

    await query.answer()
    await query.edit_message_text(
        full,
        parse_mode="Markdown",
        disable_web_page_preview=True
    )