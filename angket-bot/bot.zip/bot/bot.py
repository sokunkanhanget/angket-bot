from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler, TypeHandler

from bot.analysis.utils import init_db, init_url_db
from bot.config import TELEGRAM_BOT_TOKEN, VIRUSTOTAL_API_KEY
from bot.handlers.file_handler import handle_file
from bot.handlers.text_handler import handle_text, start
from bot.handlers.url_handler import see_why_callback, handle_url
from bot.handlers.router import route_text

def main():
    if not TELEGRAM_BOT_TOKEN or not VIRUSTOTAL_API_KEY:
        print("Error: Missing TELEGRAM_BOT_TOKEN or VIRUSTOTAL_API_KEY in .env file.")
        return

    init_db()
    init_url_db()
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    async def _log_every_update(update, context):
        print(f"[UPDATE] message={update.message} | edited={update.edited_message} | callback={update.callback_query}")

    async def _on_error(update, context):
        print(f"[ERROR] {context.error!r}")

    app.add_handler(TypeHandler(Update, _log_every_update), group=-1)   # group=-1 = runs first, logs, doesn't block
    app.add_error_handler(_on_error)

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_file))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_url))
    app.add_handler(MessageHandler(filters.TEXT & filters.UpdateType.BUSINESS_MESSAGE, handle_business_url))
    app.add_handler(CallbackQueryHandler(see_why_callback, pattern="^why:"))

    print("🤖 Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()